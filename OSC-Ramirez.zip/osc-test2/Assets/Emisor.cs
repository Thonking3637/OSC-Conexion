﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using extOSC;

public class Emisor : MonoBehaviour
{   
    public OSCTransmitter trasmisor;
    // Start is called before the first frame update
    void Update()
    {       
     OSCMessage message =  new OSCMessage("/prueba");
     message.AddValue (OSCValue.String("Hola"));
     trasmisor.Send(message);   
    }

    // Update is called once per frame
 

}
