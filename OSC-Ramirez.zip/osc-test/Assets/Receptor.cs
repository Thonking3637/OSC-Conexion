﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using extOSC;
public class Receptor : MonoBehaviour
{
    public OSCReceiver receptor;
    // Start is called before the first frame update
    void Start()
    {
        receptor.Bind("/prueba", OnReceivePrueba);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnReceivePrueba(OSCMessage message){
        Debug.Log(message);
    }
}
