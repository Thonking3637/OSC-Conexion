﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using extOSC;
public class Movement : MonoBehaviour
{
    public OSCTransmitter trasmisor;
    float speed = 1;
    // Start is called before the first frame update
    // Update is called once per frame
    void Update()
    {
        
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");

        transform.position += new Vector3(h*speed, v*speed, 0);

        OSCMessage message =  new OSCMessage("/prueba");
        message.AddValue (OSCValue.Float(transform.position.x));
             message.AddValue (OSCValue.Float(transform.position.y));
        
        trasmisor.Send(message);
    }
}
